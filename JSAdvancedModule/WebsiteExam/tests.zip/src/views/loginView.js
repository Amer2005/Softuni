import { login } from "../api/user.js";
import { html } from "../lib.js";
import { createSubmitHandler } from "../util.js";

const loginTemp = (handler) => html`
<section id="login">
    <div @submit=${handler} class="form">
        <h2>Login</h2>
        <form class="login-form">
        <input type="text" name="email" id="email" placeholder="email" />
        <input type="password" name="password" id="password" placeholder="password" />
        <button type="submit">login</button>
        <p class="message">
            Not registered? <a href="#">Create an account</a>
        </p>
        </form>
    </div>
</section>
`;


export async function showLogin(ctx){
    ctx.render(loginTemp(createSubmitHandler(onLogin)));

    async function onLogin({email, password}) {
         if(!email || !password){
            return alert("fields empty");
         }
         await login(email, password);
         ctx.updateNav();
         ctx.page.redirect("/dashboard");
    }
}
