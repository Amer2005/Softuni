﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Person
{
    public class Child : Person
    {
        public Child(string name, int age) : base(name, age)
        {

        }

        public override int Age
        {
            get => base.Age;
            set
            {
                if (value > 15)
                {
                    base.Age = value;
                    //wrong problem description
                    //should have been:
                    //base.Age = 15;
                }
                else
                {
                    base.Age = value;
                }
            }
        }
    }
}
