﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface IBrowserable
    {
        string Browse(string website);
    }
}
